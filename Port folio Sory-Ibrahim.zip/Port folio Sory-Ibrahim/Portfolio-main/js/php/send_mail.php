<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the form
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $address = htmlspecialchars($_POST['address']);
    $message = htmlspecialchars($_POST['message']);
    
    // Define the recipient email
    $to = 'Sory45900@gmail.com';
    $subject = 'New Contact Form Submission';
    $body = "Nom: $name\nEmail: $email\nTelephone: $phone\nAddress: $address\nMessage:\n$message";
    $headers = "From: $email";

    // Send the email

    if (isset($_GET['status']) && $_GET['status'] == 'success') {
        echo '<div class="success-message"><img src="thumbs-up.png" alt="Pouce Bleu"> Message envoyé avec succès.</div>';
    } elseif (isset($_GET['status']) && $_GET['status'] == 'error') {
        echo '<div class="error-message">Erreur lors de l\'envoi du message.</div>';
    }}
    ?>